import React from 'react'
// import BrandAssetsMenu from './Components/BrandAssetsMenu'
// import Templates from './Components/Templates'
// import BrandAssets from './Components/BrandAssets'
// import BrandAssetsMenu from './Components/BrandAssetsMenu'
// import BrandAssetsList from './Components/BrandAssetsLists'
import LogoOptions from './Components/LogoOptions'

const App = () => {
  return (
    <div>
   {/* <BrandAssetsList/> 
      <BrandAssets/>
      <BrandAssetsMenu/>
     <Templates/> */}
     <LogoOptions/>
    </div>
  )
}

export default App
