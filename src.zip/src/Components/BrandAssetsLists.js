import MaterialTable from "material-table";
import './BrandAssetsLists.css';


const BrandAssets = () => {
    return (
      <div style={{width: "350px"}}>
      <MaterialTable  className='MuiToolbar-gutters' className="MuiIconButton-root" className="MTableToolbar-root-18" className="MuiTypography-h6" className="MTableToolbar-root-5" className='.MuiToolbar-root.MuiToolbar-regular.MTableToolbar-root-5.MuiToolbar-gutters'
     
     className='MuiTableCell-head' className='MuiTableCell-root' 

        title=" Brand Assets Lists "
        columns={[
          { title: 'Assets Type', 
          field: 'assetsType' ,  
          },

          // { title: 'Education Only Menu Item ',
          //  field: 'educationOnlyItemMenu',
          //  headerStyle:{textAlign:""},
          //   render:() => <div className="check"><input type="checkbox"/></div>
          // }, 
          // { title: 'Organization  Menu',
          //  field: 'organization',
          //  headerStyle:{textAlign:""},
          //   render:() => <div className="check"><input type="checkbox"/></div>
          // }, 
         
        ]}
        options={{
            search: false,
            sorting: false,
            paging:false,
            draggable:false,
            headerStyle: {
              color: '#15355C',
              fontSize:"20px",
              fontWeight:"750",
              lineHeight:"2em",
            
            },
           
            rowStyle: ( data, index ) => ({
              backgroundColor:
              index % 2 === 0 ? "rgb(242,244,246)" : "white",
              color:"rgb(242,244,246)",
            }),
            
           
               cellStyle:{
            padding:"0 0 0 1px",
            border: "0px",
          
            color: '#15355C',
            fontWeight:650,
           },
  
        }}
        components={{Container: props => (
          <div style={{
            padding:"10px"
           }}>
            <div {...props} />
          </div>)
          }}
        
        
        data={[
          {},
          { assetsType: ' Logos' },
          { assetsType: 'School Motos' },
          { assetsType: 'Positive Education Banners'},
          { assetsType: 'Colours'},
          { assetsType: 'Fonts'},
          { assetsType: 'Patterns' },
          { assetsType: 'Icons' },
          { assetsType: 'Mascots' },
          { assetsType: 'Approved Images' },
          { assetsType: 'Videos' },
          { assetsType:'Audios '}
        ]}  
        // style={{ 
        //   margin: "0px 30px",
        //   border: "1px solid black",
        //   padding: "20px 0px",
          
        //     }}      
        actions={[]}
        
      />
      </div>
    )
  }

  export default BrandAssets;