import MaterialTable from "material-table";
import './LogoOptions.css';


const BrandAssets = () => {
    return (
      <div className="Tablecontainer">
      <MaterialTable  className='MuiToolbar-gutters' className="MuiIconButton-root" className="MTableToolbar-root-18" className="MuiTypography-h6" className="MTableToolbar-root-5" className='MuiToolbar-root.MuiToolbar-regular.MTableToolbar-root-5.MuiToolbar-gutters'
     
     className='MuiTableCell-head' className='MTableToolbar-actions-8' className='td.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft '

        title=" "
        columns={[
          { title: 'Logo Options', 
          field: 'logooptions' ,
          },

          { title: ' ',
           field: 'sizeincm',
           headerStyle:{textAlign:"center"},
            // render:() => <div className="check"><input type="checkbox"/></div>
          }, 

          { title: ' ',
           field: 'sizeindpi',
           headerStyle:{textAlign:"center"},
            // render:() => <div className="check"><input type="checkbox"/></div>
          },

          { title: ' ',
           field: 'filetype',
           headerStyle:{textAlign:"center"},
            // render:() => <div className="check"><input type="checkbox"/></div>
          },

          { title: ' ',
           field: 'comments',
           headerStyle:{textAlign:"center"},
            // render:() => <div className="check"><input type="checkbox"/></div>
          },
           
         
        ]}
        options={{
            search: false,
            sorting: false,
            paging:false,
            draggable:false,
            headerStyle: {
              color: '#15355C',
              fontSize:"20px",
              fontWeight:"750",
              lineHeight:"2em",
            
            },
           
            rowStyle: ( data, index ) => ({
              backgroundColor:
              index % 2 === 1 ? "rgb(242,244,246)" : "white",
              color:"rgb(242,244,246)",
              
              

            }),
               cellStyle:{
            padding:"0 0 0 3px",
            border:"0px",
            color: '#15355C',
            fontWeight:650,
           },
  
        }}
        components={{Container: props => (
          <div style={{
            padding:"10px"
           }}>
            <div {...props} />
          </div>)
          }}
        
        
        data={[
          { logooptions: ' Logo Type Name',sizeincm:<p className='value'>Default size cms</p>,sizeindpi:<p className='value'>Default Size DPI</p>, filetype:<p className='value'>Default File Type</p>,comments:<p className='value'>Comments</p>},
          { logooptions: ' Large',sizeincm:<p className="p">10x10</p>,sizeindpi:<p className="p">300 DPI</p>, filetype:<p className="p">PNG</p>,comments:<p className="p">This is a comment</p>},
          { logooptions: ' Medium',sizeincm:<p className="p">10x10</p>,sizeindpi:<p className="p">300 DPI</p>, filetype:<p className="p">PNG</p>,comments:<p className="p">This is a comment</p>},
          { logooptions: ' Small',sizeincm:<p className="p">10x10</p>,sizeindpi:<p className="p">300 DPI</p>, filetype:<p className="p">PNG</p>,comments:<p className="p">This is a comment</p>},
          { logooptions: ' Large Format Printing',sizeincm:<p className="p">10x10</p>,sizeindpi:<p className="p">300 DPI</p>, filetype:<p className="p">PNG</p>,comments:<p className="p">This is a comment</p>},
          { logooptions: ' Email Signature',sizeincm:<p className="p">10x10</p>,sizeindpi:<p className="p">300 DPI</p>, filetype:<p className="p">PNG</p>,comments:<p className="p">This is a comment</p>},
        ]}  


        actions={[
       
          {
                icon: () => <div className="addbuttonfield"><span className="plusfield"> + </span> <span className="addcategorytext"> ADD CATEGORY </span> </div>,
            //     iconProps: { style: { 
            //     // fontSize:"1px",
            //     // border:"1px solid black",
            //     // borderRadius:"3px",
            //     // borderLeft:"20px solid #15355C",
            //     // width:"100%",
            //     // padding:"3px",          
            // } },
                isFreeAction: true,
                onClick: (event) => alert("You want to add a new row")
              }

        ]}
        
      />
      </div>
    )
  }

  export default BrandAssets;