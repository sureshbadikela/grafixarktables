import MaterialTable from "material-table";

import './Templates.css';



const Templates = () => {
    return (
      <div className='tablecontainer'>
      <MaterialTable className='MuiToolbar-gutters' className="MuiIconButton-root" className="MTableToolbar-root-18" className="MuiTypography-h6" className="MTableToolbar-root-5" className='.MuiToolbar-root.MuiToolbar-regular.MTableToolbar-root-5.MuiToolbar-gutters'
     
       className='MuiTableCell-head'

       

     title="Templates Menu"
        columns={[
          { title: 'Category Name Menu', 
          field: 'categoryMenu' , width:'3%!important',
          },

          { title: 'Education OnlyItem Menu ',
           field: 'educationOnlyItemMenu',
           headerStyle:{textAlign:""},
            render:() => <div className="check"><input type="checkbox"/></div>
          }, 
          { title: 'Organization Menu ',
           field: 'org menu',
           headerStyle:{textAlign:""},
            render:() => <div className="check"><input type="checkbox"/></div>
          }, 
         
        ]}
        options={{
            search: false,
            sorting: false,
            paging:false,
            draggable:false,
            headerStyle: {
              color: '#15355C',
              fontSize:"20px",
              fontWeight:"750",
            lineHeight:'2em',
            
          
            },
            rowStyle: ( data, index ) => ({
              backgroundColor:
              index % 2 === 1 ? "rgb(242,244,246)" : "white",
              color:"rgb(242,244,246)",
            }),
               cellStyle:{
            padding:"0 0 0 8px",
            // paddingLeft:"15px",
            fontsize:"15px",
            border:"0px",
            fontWeight:"650",
            color: '#15355C',
            
           },
  
        }}
        components={{Container: props => (
          <div style={{
            padding:"10px"
           }}>
            <div {...props} />
          </div>)
          }}
        
        
        data={[
          {},
          { categoryMenu: 'Letterhead' },
          { categoryMenu: 'Email Signature' },
          { categoryMenu: 'Certificates'},
          { categoryMenu: 'Booklets'},
          { categoryMenu: 'Permisssion Notes'},
          { categoryMenu: 'Envelopes' },
          { categoryMenu: 'Social Media' },
          { categoryMenu: 'Newsletter' },
          { categoryMenu: 'Reports' },
          { categoryMenu: 'Other' },
        ]}  
        // style={{ 
        //   margin: "0px 30px",
        //   border: "1px solid black",
        //   padding: "20px 0px",
          
        //     }}      
        actions={[
            {
                icon: () => <div className="addbuttonfield"><span className="plusfield"> + </span> <span className="addcategorytext"> ADD CATEGORY </span> </div>,
            //     iconProps: { style: { 
            //     // fontSize:"1px",
            //     // border:"1px solid black",
            //     // borderRadius:"3px",
            //     // borderLeft:"20px solid #15355C",
            //     // width:"100%",
            //     // padding:"3px",          
            // } },
                isFreeAction: true,
                onClick: (event) => alert("You want to add a new row")
              }
            
        ]}
        
      />
      </div>
    )
  }

  export default Templates;